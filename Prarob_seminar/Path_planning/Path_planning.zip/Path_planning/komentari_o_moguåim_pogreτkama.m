%komentari o mogućim pogreškama
%negdje kod transformacija_matrica
%kod one moje transformacije između pixela slike i mape
%